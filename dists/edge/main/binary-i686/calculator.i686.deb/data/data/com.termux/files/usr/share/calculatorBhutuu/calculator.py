#!/usr/bin/python

runner = True

def add(a, b):
    return a+b
def subtract(a, b):
    return a-b
def multiply(a, b):
    return a*b
def divide(a, b):
    return a/b
def exponent(a, b):
    return a**b
def askNumbers():
    a=float(input('Enter first number: '))
    b=float(input('Enter second number: '))
    return a, b
def main():
    global runner
    while runner is True:
        print("""
Choose the operation from following
(1). Addition of two number
(2). Subtraction of two number
(3). Multiplication of two number
(4). Division of two number
(5). exponent of number a by b
(6). Exit
""")
        userInput = int(input("Enter the index of operation: "))
        if userInput:
            if userInput == 1:
                a, b = askNumbers()
                print(add(a,b))
            elif userInput == 2:
                a, b = askNumbers()
                print(subtract(a,b))
            elif userInput == 3:
                a, b = askNumbers()
                print(multiply(a,b))
            elif userInput == 4:
                a, b = askNumbers()
                print(divide(a,b))
            elif userInput == 5:
                a, b = askNumbers()
                print(exponent(a,b))
            elif userInput == 6:
                runner=False
            else:
                print("Enter any valid input only!")
        else:
            print("Don't leave it blank")

if __name__ == '__main__':
    main()
